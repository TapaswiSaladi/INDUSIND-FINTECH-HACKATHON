function validateLoginForm() {
	var username = document.forms["memberLoginForm"]["username"].value;
	var password = document.forms["memberLoginForm"]["password"].value;
	if ((username == "") || (password == "")) {
		alert("Username or Password can not be blank");
		return false;
	} else {
		return true;
	}
};

function validateCustomerOnboardForm1() {
	var aadharNo = document.forms["customerOnboardingForm1"]["aadharNo"].value;
	var contactNo = document.forms["customerOnboardingForm1"]["contactNo"].value;
	if ((aadharNo == "") || (contactNo == "")) {
		alert("Aadhar number or Contact number can not be blank");
		return false;
	} else {
		return true;
	}
};

function validateViewStatementForm()
{
	var accountNumber = document.forms["viewStatementForm"]["accountNumber"].value;
	var startDate = document.forms["viewStatementForm"]["startDate"].value;
	var endDate = document.forms["viewStatementForm"]["endDate"].value;
	if ((accountNumber == "") || (startDate == "") || (endDate == "")) 
	{
		alert("All fields are mandatory");
		return false;
	} else {
		return true;
	}
}

function validateCustomerOnboardForm2() 
{
	var retVal = true;
	var aadharNo = document.forms["customerOnboardingForm2"]["aadharNo"].value;
	var customerName = document.forms["customerOnboardingForm2"]["customerName"].value;
	var age = document.forms["customerOnboardingForm2"]["age"].value;
	var contactNo = document.forms["customerOnboardingForm2"]["contactNo"].value;
	/*
	 * var memberID =
	 * document.forms["customerOnboardingForm2"]["memberID"].value;
	 */
	var otp = document.forms["customerOnboardingForm2"]["otp"].value;
	var isValidcontactNo = /^[0-9]{10}$/.test(contactNo);
	var isValidaadharNo = /^[0-9]{12}$/.test(aadharNo);
	if ((aadharNo == "") || (customerName == "") || (age == "")
			|| (contactNo == "") || /* (memberID == "") || */(otp == "")) 
	{
		alert("Aadhar number or, Customer Name or, Age or, Contact Number or, OTP can not be blank");
		retVal = false;
	}
	if (!isValidaadharNo) 
	{
		alert("Aadhar number must be of 12 digits only");
		retVal = false;
	} 
	if ((parseInt(age, 10) < 18) || (parseInt(age, 10) > 90)) 
	{
		alert("Age must be between 18 and 90 (both limit inclusive)");
		retVal = false;
	} 
	if (!isValidcontactNo) 
	{
		alert("Contact number must be of 10 digits only");
		retVal = false;
	} 
	else 
	{
		retVal = true;
	}
};

/*function validateCreateCustomerAccountForm() {
	console.log('I am in Validation');
	var retVal = true;
	var salutation = document.forms["createCustomerAccountForm"]["salutation"].value;	
	var firstName = document.forms["createCustomerAccountForm"]["firstName"].value;
	var lastName = document.forms["createCustomerAccountForm"]["lastName"].value;
	var contactNo = document.forms["createCustomerAccountForm"]["contactNo"].value;
	var dob = document.forms["createCustomerAccountForm"]["dob"].value;
	var nationality = document.forms["createCustomerAccountForm"]["nationality"].value;
	var maritalStatus = document.forms["createCustomerAccountForm"]["maritalStatus"].value;
	var motherMaidenName = document.forms["createCustomerAccountForm"]["motherMaidenName"].value;
	var fatherName = document.forms["createCustomerAccountForm"]["fatherName"].value;
	var panNo = document.forms["createCustomerAccountForm"]["panNo"].value;
	var addressType = document.forms["createCustomerAccountForm"]["addressType"].value;
	var addressProof = document.forms["createCustomerAccountForm"]["addressProof"].value;
	var landMark = document.forms["createCustomerAccountForm"]["landMark"].value;
	var address = document.forms["createCustomerAccountForm"]["address"].value;
	var city = document.forms["createCustomerAccountForm"]["city"].value;
	var state = document.forms["createCustomerAccountForm"]["state"].value;
	var pincode = document.forms["createCustomerAccountForm"]["pincode"].value;
	var accountType = document.forms["createCustomerAccountForm"]["accountType"].value;
	var openingAmount = document.forms["createCustomerAccountForm"]["openingAmount"].value;
	console.log('salutation = '+salutation);
	
	var contactNoRegex = RegExp('^[0-9]{10}$');
	var pincodeRegex = RegExp('^[0-9]{6}$');
	
	if ((salutation == '') || (firstName == '')  || (lastName == '') || (contactNo == '') ||
			(dob == '')  || (nationality == '')  || (maritalStatus == '')  || (motherMaidenName == '') ||
			(fatherName == '')  || (panNo == '')  || (addressType == '')  || (addressProof == '') ||
			(address == '') || (city == '') ||  (state == '') || (pincode == '') || (accountType == '') ||  (openingAmount == '')) 
	{
		console.log('Marked fields can not be blank');
		alert('(*) Marked fields can not be blank')
		retVal = false;
	}
	if (contactNo != '') 
	{
		if(!contactNoRegex.test(contactNo))
		{
			console.log("Contact number is not valid");
			alert("Contact number is not valid");
			retVal = false;
		}
	}
	if (pincode != '')
	{
		console.log('pincode = '+pincode);
		if(!pincodeRegex.test(pincode))
		{
			console.log("Pincode is not valid");
			alert("Pincode is not valid");
			retVal = false;
		}
	}
	console.log('Validation Ended == ' + retVal);
	return retVal;
};*/

function validateCreateCustomerAccountForm() {
	console.log('I am in Validation');
	var retVal = true;
	var contactNo = document.forms["createCustomerAccountForm"]["contactNo"].value;
	var pincode = document.forms["createCustomerAccountForm"]["pincode"].value;
	
	var contactNoRegex = RegExp('^[0-9]{10}$');
	var pincodeRegex = RegExp('^[0-9]{6}$');

	if (contactNo != '') 
	{
		if(!contactNoRegex.test(contactNo))
		{
			console.log("Contact number is not valid");
			alert("Contact number is not valid");
			retVal = false;
		}
	}
	if (pincode != '')
	{
		console.log('pincode = '+pincode);
		if(!pincodeRegex.test(pincode))
		{
			console.log("Pincode is not valid");
			alert("Pincode is not valid");
			retVal = false;
		}
	}
	console.log('Validation Ended == ' + retVal);
	return retVal;
};

function validateDepositWithdrawalForm()
{
	console.log('I am in Validation');
	var retVal = true;
	var accountNumber = document.forms["depositWithdrawalForm"]["accountNumber"].value;	
	var transactionAmount = document.forms["depositWithdrawalForm"]["transactionAmount"].value;
	var transactionType = document.forms["depositWithdrawalForm"]["transactionType"].value;
	var description = document.forms["depositWithdrawalForm"]["description"].value;
	
	var accountBalance = parseFloat(accountNumber.split("#")[1]);
	
	var transactionAmountRegex = RegExp('^[0-9]+$');
	
	if((accountNumber == '') || (transactionAmount == '') || (transactionType == '') || (description == ''))
	{
		alert('All fields are mandatory');
		retVal = false;
	}
	if ((transactionAmount != "") && ((transactionType == "Debit") || (transactionType == "Credit"))) 
	{
		console.log("Transaction Amount is = " + transactionAmount);
		console.log("transactionAmountRegex.test(transactionAmount) : " + transactionAmountRegex.test(transactionAmount));
		if(!transactionAmountRegex.test(transactionAmount))
		{
			alert("Transaction Amount should be digits only");
			retVal = false;
		}
		else
		{
			if(transactionType == "Debit")
			{
				var transactionAmt = parseFloat(transactionAmount);
				if(accountBalance < transactionAmt)
				{
					console.log("Transaction Amount is = " + transactionAmt);
					console.log("accountBalance is = " + accountBalance);
					alert("Transaction not allowed. Insufficient fund");
					retVal = false;
				}
			}
		}
	}
	/*if(transactionType == "Debit")
	{
		if(accountBalance < transactionAmt)
		{
			console.log("Transaction Amount is = " + transactionAmt);
			console.log("accountBalance is = " + accountBalance);
			alert("Transaction not allowed. Insufficient fund");
			retVal = false;
		}
	}*/
	
	console.log('Validation Ended == ' + retVal);
	return retVal;
};

function validateOTPForm() 
{
	var generatedOTP = document.forms["OTPForm"]["generatedOTP"].value;
	var enteredOTP = document.forms["OTPForm"]["enteredOTP"].value;

	if(generatedOTP == enteredOTP)
	{
		return true;
	}
	else
	{
		alert('OTP is incorrect');
		return false;
	}
};