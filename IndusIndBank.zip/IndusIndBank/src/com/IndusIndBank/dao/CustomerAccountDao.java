package com.IndusIndBank.dao;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

import com.IndusIndBank.bean.CustomerAccountBean;
import com.IndusIndBank.bean.CustomerTransactionBean;
import com.IndusIndBank.bean.KiranMemberBean;
import com.IndusIndBank.controller.loginServlet;
import com.IndusIndBank.util.AESEncryptDecryptUtil;
import com.IndusIndBank.util.MongoDBConnection;
import com.IndusIndBank.util.utility;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class CustomerAccountDao 
{
	public String createCustomerAccount(CustomerAccountBean customerAccountBean) 
	{
		String output = "";
		
		if(customerAccountBean != null)
		{
			String POST_PARAMS = "{\n" + "\"customerAccNumber\": \""+ customerAccountBean.getCustomerAccNumber() +"\",\r\n" +
					"	 \"accountOpeningDate\": \""+ utility.getCurrentDate().split("\\#")[0] +"\",\r\n" +
					"	 \"customerID\": \""+ customerAccountBean.getCustomerID() +"\",\r\n" +
					"    \"aadharNo\": \""+ customerAccountBean.getAadharNo() +"\",\r\n" +
			        "    \"age\": \""+ customerAccountBean.getAge() +"\",\r\n" +
			        "    \"customerName\": \""+ customerAccountBean.getCustomerName() +"\",\r\n" +
			        "    \"contactNo\": "+ customerAccountBean.getContactNo() +",\r\n" +
			        "    \"emailID\": \""+ customerAccountBean.getEmailID() +"\",\r\n"+
			        "    \"dob\": \""+ customerAccountBean.getDob() +"\",\r\n"+
			        "    \"nationality\": \""+ customerAccountBean.getNationality() +"\",\r\n"+
			        "    \"gender\": \""+ customerAccountBean.getGender() +"\",\r\n"+
			        "    \"maritalStatus\": \""+ customerAccountBean.getMaritalStatus() +"\",\r\n"+
			        "    \"motherMaidenName\": \""+ customerAccountBean.getMotherMaidenName() +"\",\r\n"+
			        "    \"fatherName\": \""+ customerAccountBean.getFatherName() +"\",\r\n"+
			        "    \"panNo\": \""+ customerAccountBean.getPanNo() +"\",\r\n"+
			        "    \"addressProof\": \""+ customerAccountBean.getAddressProof() +"\",\r\n"+
			        "    \"addressList\": ["
			        						+ "{\"addressType\":\""+ customerAccountBean.getAddressList().get(0).getAddressType() +"\","
			        						+ "\"address\":\""+ customerAccountBean.getAddressList().get(0).getAddress() +"\"}"
			        					+ "], \r\n"+
			        "    \"accountType\": \""+ customerAccountBean.getAccountType() +"\",\r\n"+
			        "    \"openingAmount\": \""+ customerAccountBean.getOpeningAmount() +"\",\r\n"+
			        "    \"jointAccHolderName\": \""+ customerAccountBean.getJointAccHolderName() + "\" \n}";
			
			System.out.println("POST_PARAMS : " + POST_PARAMS);
			
			try
			{
				URL url = new URL(LoginDao.prop.getProperty("restAPI_addCustomerAccount").trim());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");

				OutputStream os = conn.getOutputStream();
				os.write(POST_PARAMS.getBytes());
				os.flush();
				
				if ((conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) ||
						(conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) ||
						(conn.getResponseCode() == HttpURLConnection.HTTP_OK)) 
				{
					System.out.println("Successfully posted");
					
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					
					String str;
					System.out.println("Output from Server .... \n");
					while ((str = br.readLine()) != null) 
					{
						output += str;
						System.out.println(output);
					}
				}
				else
				{
					System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
				}
				conn.disconnect();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		return output;
	}

	public void updateTransactionTableFirstTime(CustomerAccountBean customerAccountBean) 
	{
		if(customerAccountBean.getOpeningAmount() > 0.0)
		{
			CustomerTransactionBean customerTransactionBean = new CustomerTransactionBean();
			
			String currentTimestamp = utility.getCurrentDate();
			System.out.println("from CustomerAccountDao , newAccNumber: " + customerAccountBean.getCustomerAccNumber());
			customerTransactionBean.setCustomerAccNumber(customerAccountBean.getCustomerAccNumber());
			customerTransactionBean.setTransactionDate(currentTimestamp.split("\\#")[0]);
			customerTransactionBean.setCustomerID(customerAccountBean.getCustomerID());
			customerTransactionBean.setCustomerName(customerAccountBean.getCustomerName());
			customerTransactionBean.setContactNo(customerAccountBean.getContactNo());
			customerTransactionBean.setEmailID(customerAccountBean.getEmailID());
			customerTransactionBean.setCreditedAmount(customerAccountBean.getOpeningAmount());
			customerTransactionBean.setDebitedAmount(0.0);
			customerTransactionBean.setAccountBalance(customerAccountBean.getOpeningAmount());
			customerTransactionBean.setDescription(LoginDao.prop.getProperty("newAccountOpeningDesc"));
			customerTransactionBean.setTransactionTimestamp(Long.parseLong(currentTimestamp.split("\\#")[1]));
			
			String POST_PARAMS = "{\n" + "\"customerAccNumber\": \""+ customerTransactionBean.getCustomerAccNumber() +"\",\r\n" +
					"	 \"transactionDate\": \""+ customerTransactionBean.getTransactionDate() +"\",\r\n" +
					"	 \"customerID\": \""+ customerTransactionBean.getCustomerID() +"\",\r\n" +
					"    \"customerName\": \""+ customerTransactionBean.getCustomerName() +"\",\r\n" +
			        "    \"contactNo\": \""+ customerTransactionBean.getContactNo() +"\",\r\n" +
			        "    \"emailID\": \""+ customerTransactionBean.getEmailID() +"\",\r\n" +
			        "    \"creditedAmount\": "+ customerTransactionBean.getCreditedAmount() +",\r\n" +
			        "    \"debitedAmount\": \""+ customerTransactionBean.getDebitedAmount() +"\",\r\n"+
			        "    \"accountBalance\": \""+ customerTransactionBean.getAccountBalance() +"\",\r\n"+
			        "    \"description\": \""+ customerTransactionBean.getDescription() +"\",\r\n"+
			        "    \"transactionTimestamp\": \""+ customerTransactionBean.getTransactionTimestamp() + "\" \n}";
			
			System.out.println("POST_PARAMS : " + POST_PARAMS);
			
			try
			{
				URL url = new URL(LoginDao.prop.getProperty("restAPI_updateCustomerTransactionFirstTime").trim());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");

				OutputStream os = conn.getOutputStream();
				os.write(POST_PARAMS.getBytes());
				os.flush();
				
				if ((conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) ||
						(conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) ||
						(conn.getResponseCode() == HttpURLConnection.HTTP_OK)) 
				{
					System.out.println("Successfully posted");
					
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					
					String str;
					String output = "";
					System.out.println("Output from Server .... \n");
					while ((str = br.readLine()) != null) 
					{
						output += str;
						System.out.println(output);
					}
				}
				else
				{
					System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
				}
				conn.disconnect();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	
	public ArrayList<CustomerTransactionBean> viewAccountBalance(String customerID) 
	{
		ArrayList<CustomerTransactionBean> customerAccountBalanceList = new ArrayList<CustomerTransactionBean>();
		
		try
		{
			String url = LoginDao.prop.getProperty("restAPI_viewCustomerAccountBalance").trim();
			url = url.replace("{customerID}", customerID);
			System.out.println("URL : " + url);
			
			URL obj = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json");
			
			if ((conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) ||
					(conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) ||
					(conn.getResponseCode() == HttpURLConnection.HTTP_OK)) 
			{
				System.out.println("Successfully posted");
				
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				
				String str;
				
				StringBuffer response = new StringBuffer();
				
				System.out.println("Output from Server .... \n");
				while ((str = br.readLine()) != null) 
				{
					response.append(str);
				}
				br.close();
				System.out.println(response.toString());
				
				JSONArray jsonArr = new JSONArray(response.toString());
				
				for (int i = 0 ; i < jsonArr.length() ; i++)
				{
					JSONObject jsonArrObj = jsonArr.getJSONObject(i);
					System.out.println(jsonArrObj.getDouble("accountBalance"));
					
					CustomerTransactionBean customerTransactionBean = new CustomerTransactionBean();
					
					customerTransactionBean.setCustomerAccNumber(jsonArrObj.getLong("customerAccNumber"));
					customerTransactionBean.setCustomerID(jsonArrObj.getString("customerID"));
					customerTransactionBean.setCustomerName(jsonArrObj.getString("customerName"));
					customerTransactionBean.setContactNo(jsonArrObj.getString("contactNo"));
					customerTransactionBean.setEmailID(jsonArrObj.getString("emailID"));
					customerTransactionBean.setAccountBalance(jsonArrObj.getDouble("accountBalance"));
					
					customerAccountBalanceList.add(customerTransactionBean);
				}
			}
			else
			{
				System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
			}
			conn.disconnect();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return customerAccountBalanceList;
	}

	public String updateCustomerTransaction(CustomerTransactionBean customerTransactionBean) 
	{
		String output = "";
		
		String POST_PARAMS = "{\n" + "\"customerAccNumber\": \""+ customerTransactionBean.getCustomerAccNumber() +"\",\r\n" +
				"	 \"transactionDate\": \""+ customerTransactionBean.getTransactionDate() +"\",\r\n" +
				"	 \"customerID\": \""+ customerTransactionBean.getCustomerID() +"\",\r\n" +
				"    \"customerName\": \""+ customerTransactionBean.getCustomerName() +"\",\r\n" +
		        "    \"contactNo\": \""+ customerTransactionBean.getContactNo() +"\",\r\n" +
		        "    \"emailID\": \""+ customerTransactionBean.getEmailID() +"\",\r\n" +
		        "    \"creditedAmount\": "+ customerTransactionBean.getCreditedAmount() +",\r\n" +
		        "    \"debitedAmount\": \""+ customerTransactionBean.getDebitedAmount() +"\",\r\n"+
		        "    \"accountBalance\": \""+ customerTransactionBean.getAccountBalance() +"\",\r\n"+
		        "    \"description\": \""+ customerTransactionBean.getDescription() +"\",\r\n"+
		        "    \"transactionTimestamp\": \""+ customerTransactionBean.getTransactionTimestamp() + "\" \n}";
		
		System.out.println("POST_PARAMS : " + POST_PARAMS);
		
		try
		{
			URL url = new URL(LoginDao.prop.getProperty("restAPI_updateCustomerTransaction").trim());
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");

			OutputStream os = conn.getOutputStream();
			os.write(POST_PARAMS.getBytes());
			os.flush();
			
			if ((conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) ||
					(conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) ||
					(conn.getResponseCode() == HttpURLConnection.HTTP_OK)) 
			{
				System.out.println("Successfully posted");
				
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				
				String str;
				System.out.println("Output from Server .... \n");
				while ((str = br.readLine()) != null) 
				{
					output += str;
					System.out.println(output);
				}
			}
			else
			{
				System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
			}
			conn.disconnect();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return output;
	}

	public ArrayList<CustomerTransactionBean> getSOA(String customerAccNumber, String startDateTimestamp, String endDateTimestamp) 
	{
		ArrayList<CustomerTransactionBean> CustomerTransactionBeanList = new ArrayList<CustomerTransactionBean>();
		
		try
		{
			String url = LoginDao.prop.getProperty("restAPI_viewCustomerAccountStatement").trim();
			url = url.replace("{customerAccNumber}", customerAccNumber);
			url = url.replace("{startDate}", startDateTimestamp);
			url = url.replace("{endDate}", endDateTimestamp);
			System.out.println("URL : " + url);
			
			URL obj = new URL(url);
			HttpURLConnection conn = (HttpURLConnection) obj.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json");
			
			if ((conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) ||
					(conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) ||
					(conn.getResponseCode() == HttpURLConnection.HTTP_OK)) 
			{
				System.out.println("Successfully posted");
				
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				
				String str;
				
				StringBuffer response = new StringBuffer();
				
				System.out.println("Output from Server .... \n");
				while ((str = br.readLine()) != null) 
				{
					response.append(str);
				}
				br.close();
				System.out.println(response.toString());
				
				JSONArray jsonArr = new JSONArray(response.toString());
				
				for (int i = 0 ; i < jsonArr.length() ; i++)
				{
					JSONObject jsonArrObj = jsonArr.getJSONObject(i);
					System.out.println(jsonArrObj.getDouble("accountBalance"));
					
					CustomerTransactionBean customerTransactionBean = new CustomerTransactionBean();
					
					customerTransactionBean.setCustomerAccNumber(jsonArrObj.getLong("customerAccNumber"));
					customerTransactionBean.setTransactionDate(jsonArrObj.getString("transactionDate"));
					customerTransactionBean.setCreditedAmount(jsonArrObj.getDouble("creditedAmount"));
					customerTransactionBean.setDebitedAmount(jsonArrObj.getDouble("debitedAmount"));
					customerTransactionBean.setAccountBalance(jsonArrObj.getDouble("accountBalance"));
					customerTransactionBean.setDescription(jsonArrObj.getString("description"));
					
					CustomerTransactionBeanList.add(customerTransactionBean);
				}
			}
			else
			{
				System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
			}
			conn.disconnect();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return CustomerTransactionBeanList;
	}

	public ArrayList<KiranMemberBean> getKiranaMemberTransactionDetails(String kiranMemberID, long startDateTimestamp, long endDateTimestamp) 
	{
		System.out.println("inside getKiranaMemberTransactionDetails kirana member id : " + kiranMemberID);
		ArrayList<KiranMemberBean> kiranMemberBeanList = new ArrayList<KiranMemberBean>();
		
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionNewUserDB = LoginDao.prop.getProperty("mongoCollectionNewUserDB").trim();
			String mongoCollectionCustomerTransactionDB = LoginDao.prop.getProperty("mongoCollectionCustomerTransactionDB").trim();
			
			MongoCollection<Document> NEWUSERDB = database.getCollection(mongoCollectionNewUserDB);
			MongoCollection<Document> CUSTOMERTRANSACTIONSDB = database.getCollection(mongoCollectionCustomerTransactionDB);
			
			ArrayList<String> custIdList = new ArrayList<String>();
			
			FindIterable<Document> NEWUSERDBDoc = NEWUSERDB.find(Filters.eq("kiranaMemberID", kiranMemberID));
			
			for(Document doc : NEWUSERDBDoc)
			{
				String customerID = doc.getString("customerID");
				custIdList.add(customerID);
			}
			System.out.println(custIdList);
			
			for(int i=0; i<custIdList.size() ; i++)
			{
				double totalMoneyTaken = 0.0;
				double totalMoneyGiven = 0.0;
				
				FindIterable<Document> CUSTOMERTRANSACTIONSDBDoc = CUSTOMERTRANSACTIONSDB.find(Filters.and(Filters.eq("customerID", custIdList.get(i)),
																							Filters.gte("transactionTimestamp", startDateTimestamp),
																							Filters.lt("transactionTimestamp", endDateTimestamp)));
				
				for(Document doc1 : CUSTOMERTRANSACTIONSDBDoc)
				{
					if(doc1.getDouble("creditedAmount") != 0.0)
					{
						totalMoneyTaken += doc1.getDouble("creditedAmount" );
					}
					if(doc1.getDouble("debitedAmount") != 0.0)
					{
						totalMoneyGiven += doc1.getDouble("debitedAmount" );
					}
				}
				KiranMemberBean kiranMemberBean = new KiranMemberBean();
				kiranMemberBean.setKiranaMemberID(kiranMemberID);
				kiranMemberBean.setCustomerID(custIdList.get(i));
				kiranMemberBean.setTotalMoneyTaken(totalMoneyTaken);
				kiranMemberBean.setTotalMoneyGiven(totalMoneyGiven);
				System.out.println(custIdList.get(i) + "#" + totalMoneyTaken + "#" + totalMoneyTaken);
				kiranMemberBeanList.add(kiranMemberBean);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		
		return kiranMemberBeanList;
	}	
}

