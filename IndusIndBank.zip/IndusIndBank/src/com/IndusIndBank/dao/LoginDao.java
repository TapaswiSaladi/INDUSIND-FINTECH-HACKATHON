package com.IndusIndBank.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.IndusIndBank.util.MongoDBConnection;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import com.IndusIndBank.util.AESEncryptDecryptUtil;

public class LoginDao 
{
	final static Logger logger = Logger.getLogger(LoginDao.class);
	public static Properties prop = new Properties();
	
	public boolean validateLogin(String username, String password)
	{
		boolean loginSuccess = false;
		InputStream inputConfig = null;
		
		try 
		{
			inputConfig = this.getClass().getClassLoader()
					.getResourceAsStream("config/config.properties");
	
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		try 
		{
			prop.load(inputConfig);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				inputConfig.close();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}		
		
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(prop);
			MongoDatabase database = mongoClient.getDatabase(prop.getProperty("mongoDBName").trim());
			String mongoCollectionKiranaUsers = prop.getProperty("mongoCollectionKiranaUsers").trim();
			
			MongoCollection<Document> KiranaUsers = database.getCollection(mongoCollectionKiranaUsers);				
			
			FindIterable<Document> KiranaUsersDoc = KiranaUsers.find(Filters.eq("userID", username));
			
			for(Document doc:KiranaUsersDoc)
			{
				String pwdInDB = new AESEncryptDecryptUtil().decryptData(doc.getString("password"));
				if(password.equals(pwdInDB))
				{
					loginSuccess = true;
				}
				else
				{
					loginSuccess = false;
				}
			}
		}
		catch(Exception e)
		{
			logger.error(e);
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		return loginSuccess;
	}
}
