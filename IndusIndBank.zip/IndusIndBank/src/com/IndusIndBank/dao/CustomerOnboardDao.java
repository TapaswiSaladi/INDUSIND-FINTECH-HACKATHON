package com.IndusIndBank.dao;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.IndusIndBank.bean.AlreadyExistCheck;
import com.IndusIndBank.bean.UserBean;
import com.IndusIndBank.controller.loginServlet;
import com.IndusIndBank.util.MongoDBConnection;
import com.IndusIndBank.util.utility;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class CustomerOnboardDao 
{

	public AlreadyExistCheck validateAadhar(String aadharNo, String contactNo) 
	{
		System.out.println("inside validateAadhar");
		
		AlreadyExistCheck alreadyExistCheck = new AlreadyExistCheck();
		alreadyExistCheck.setAadharExists("false");
		alreadyExistCheck.setUserExists("false");
		
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionAadharDB = LoginDao.prop.getProperty("mongoCollectionAadharDB").trim();
			String mongoCollectionNewUserDB = LoginDao.prop.getProperty("mongoCollectionNewUserDB").trim();
			
			MongoCollection<Document> AadharDB = database.getCollection(mongoCollectionAadharDB);
			MongoCollection<Document> NEWUSERDB = database.getCollection(mongoCollectionNewUserDB);	
			
			@SuppressWarnings("deprecation")
			long count = AadharDB.count(Filters.and(Filters.eq("aadharID", aadharNo),Filters.eq("contactNo", contactNo)));
			
			
			if(count > 0)
			{
				System.out.println("aadhar id found");
				alreadyExistCheck.setAadharExists("true");
				long userCount = NEWUSERDB.count(Filters.eq("aadharNo", aadharNo));
				
				if(userCount == 0)
				{
					alreadyExistCheck.setUserExists("false");
					int otp = generateRandomInt();
					System.out.println("OTP : " + otp);
					Bson filter = new Document("aadharID", aadharNo)
										.append("contactNo", contactNo);
					Bson newValue = new Document("otp", otp);
					Bson updateOperationDocument = new Document("$set", newValue);
					AadharDB.updateOne(filter, updateOperationDocument);
					if(otp != 0)
					{
						utility.sendOTP(contactNo, LoginDao.prop.getProperty("otpMsgPrefix").trim()+" " + otp);
					}
				}
				else
				{
					alreadyExistCheck.setUserExists("true");
				}
			}
			else
			{
				alreadyExistCheck.setAadharExists("false");
				alreadyExistCheck.setUserExists("false");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		
		return alreadyExistCheck;
	}

	public boolean addUser(UserBean userBean, String otp) 
	{
		boolean addUserStatus = false;
		
		String aadharNo =  userBean.getAadharNo();
		String customerName =  userBean.getCustomerName();
		int age =  userBean.getAge();
		String contactNo =  userBean.getContactNo();
	//	String memberID =  userBean.getKiranaMemberID();
		
		CustomerOnboardDao customerOnboardDao = new CustomerOnboardDao();
		boolean otpMatched = customerOnboardDao.validateOTP(aadharNo, otp);
		
		if(otpMatched)
		{
			String kiranaMemberID = loginServlet.session.getAttribute("userID").toString();
			String customerAccNum = aadharNo + kiranaMemberID;
			System.out.println("customerAccNum : " + customerAccNum);
			if((kiranaMemberID != null) && (customerAccNum != null))
			{				
				String POST_PARAMS = "{\n" + "\"kiranaMemberID\": \""+ kiranaMemberID +"\",\r\n" +
						"    \"customerID\": \""+ customerAccNum +"\",\r\n" +
				        "    \"aadharNo\": \""+ aadharNo +"\",\r\n" +
				        "    \"customerName\": \""+ customerName +"\",\r\n" +
				        "    \"age\": "+ age +",\r\n" +
				        "    \"contactNo\": \""+ contactNo +"\",\r\n"+
				        "    \"status\": \"Active\" \n}";
				System.out.println(POST_PARAMS);
				
				try
				{
					URL url = new URL(LoginDao.prop.getProperty("restAPI_addUser").trim());
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setDoOutput(true);
					conn.setRequestMethod("POST");
					conn.setRequestProperty("Content-Type", "application/json");

					OutputStream os = conn.getOutputStream();
					os.write(POST_PARAMS.getBytes());
					os.flush();

					if ((conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) ||
							(conn.getResponseCode() == HttpURLConnection.HTTP_CREATED) ||
							(conn.getResponseCode() == HttpURLConnection.HTTP_OK)) 
					{
						System.out.println("Successfully posted");
						
						BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
						
						String str;
						String output = "";
						System.out.println("Output from Server .... \n");
						while ((str = br.readLine()) != null) 
						{
							output += str;
							System.out.println(output);
						}
						if(output.toLowerCase().contains("already exixsts"))
						{
							addUserStatus = false;
						}
						else if(output.toLowerCase().contains("true"))
						{
							addUserStatus = true;
						}
						else
						{
							addUserStatus = false;
						}
					}
					else
					{
						System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
						addUserStatus = false;
					}
					conn.disconnect();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}		
			else
			{
				addUserStatus = false;
			}
		}
		else
		{
			addUserStatus = false;
		}
		
		System.out.println("addUserStatus : " + addUserStatus);
		return addUserStatus;
	}
	
	public boolean validateOTP(String aadharNo, String otp)
	{
		boolean otpMatched = false;
		
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionAadharDB = LoginDao.prop.getProperty("mongoCollectionAadharDB").trim();
			
			MongoCollection<Document> AadharDB = database.getCollection(mongoCollectionAadharDB);	
			
			FindIterable<Document> AadharDBDoc = AadharDB.find(Filters.eq("aadharID", aadharNo));
			
			for(Document doc:AadharDBDoc)
			{
				String AadharDBOTP = doc.getInteger("otp").toString();
				if(otp.equals(AadharDBOTP))
				{
					otpMatched = true;
				}
				else
				{
					otpMatched = false;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		return otpMatched;
	}
	
	public static int generateRandomInt()
	{
		int max = 999999;
		int min = 100000;
	    Random random = new Random();
	    return random.nextInt((max - min) + 1) + min;
	}
}
