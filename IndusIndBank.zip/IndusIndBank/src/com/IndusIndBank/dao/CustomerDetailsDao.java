package com.IndusIndBank.dao;

import java.util.ArrayList;

import org.bson.Document;

import com.IndusIndBank.bean.UserBean;
import com.IndusIndBank.util.MongoDBConnection;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class CustomerDetailsDao 
{

	public ArrayList<UserBean> viewAllCustomers(String kiranaMemberID) 
	{
		System.out.println("inside viewAllCustomers");
		
		ArrayList<UserBean> userBeanList = new ArrayList<UserBean>();
		
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionNewUserDB = LoginDao.prop.getProperty("mongoCollectionNewUserDB").trim();
			
			MongoCollection<Document> NewUserDB = database.getCollection(mongoCollectionNewUserDB);	
			
			FindIterable<Document> NewUserDBDoc = NewUserDB.find(Filters.eq("kiranaMemberID", kiranaMemberID))
																	.sort(new Document("customerName",1));
			
			for(Document doc: NewUserDBDoc)
			{
				UserBean userBean = new UserBean();
				userBean.setCustomerID(doc.getString("customerID"));
				userBean.setAadharNo(doc.getString("aadharNo"));
				userBean.setCustomerName(doc.getString("customerName"));
				userBean.setAge(doc.getInteger("age"));
				userBean.setContactNo(doc.getString("contactNo"));
				userBean.setStatus(doc.getString("status"));
				
				userBeanList.add(userBean);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		
		
		return userBeanList;
	}
	
}
