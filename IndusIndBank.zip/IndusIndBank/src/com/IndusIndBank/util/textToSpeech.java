package com.IndusIndBank.util;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class textToSpeech 
{
	public static void speakOut(String text)
	{
		Voice voice;
		
		VoiceManager voiceManager = VoiceManager.getInstance();
		
		voice = voiceManager.getVoice("kevin16");
		voice.allocate();
		voice.setRate(110.0f);
		voice.speak("svaagat hay, up keigh khateigh meigh shesh hay,, "+ getSpeech(text));
	}
	public static String getSpeech(String text)
	{
		String output = "";
		
		for(int i=0 ; i<text.length() ; i++)
		{
			if(text.charAt(i) == '0')
			{
				output += "Shoonya, ";
			}
			else if(text.charAt(i) == '1')
			{
				output += "eyik, ";
			}
			else if(text.charAt(i) == '2')
			{
				output += "dough, ";
			}
			else if(text.charAt(i) == '3')
			{
				output += "teen, ";
			}
			else if(text.charAt(i) == '4')
			{
				output += "cha aar, ";
			}
			else if(text.charAt(i) == '5')
			{
				output += "paanch, ";
			}
			else if(text.charAt(i) == '6')
			{
				output += "chhey, ";
			}
			else if(text.charAt(i) == '7')
			{
				output += "saat, ";
			}
			else if(text.charAt(i) == '8')
			{
				output += "utth, ";
			}
			else if(text.charAt(i) == '9')
			{
				output += "nough, ";
			}
			else if(text.charAt(i) == '.')
			{
				output += "rupeigh,, ";
			}
			else
			{
				continue;
			}
		}
		output += "Payseigh";
		System.out.println("output : " + output);
		return output;		
	}
}
