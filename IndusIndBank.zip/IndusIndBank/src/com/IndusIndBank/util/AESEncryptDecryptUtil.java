package com.IndusIndBank.util;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

import Decoder.BASE64Encoder;


public class AESEncryptDecryptUtil
{
  private static final byte[] M_SECRETKEYVALUE = { 68, 53, 50, 
    70, 67, 66, 49, 55, 65, 57, 56, 65, 53, 70, 32, 49 };
  
  public String decryptData(String encryptedText)
    throws Exception
  {
    String plainText = "";
    try
    {
      byte[] bytePlainText = Base64.decodeBase64(encryptedText);
      Cipher cipher = Cipher.getInstance("AES");
      cipher.init(2, getEncryptionKey());
      plainText = new String(cipher.doFinal(bytePlainText));
    }
    catch (Exception e)
    {
     
      throw new Exception(e.getMessage(), e);
    }
    return plainText;
  }
  
  public String encryptData(String plainText)
    throws Exception
  {
    String encryptedText = "";
    try
    {
      Cipher cipher = Cipher.getInstance("AES");
      cipher.init(1, getEncryptionKey());
      byte[] byteEncryptedText = cipher.doFinal(plainText.getBytes());
      encryptedText = new BASE64Encoder().encode(byteEncryptedText);
    }
    catch (Exception e)
    {
    	throw new Exception(e.getMessage(), e);
    }
    return encryptedText;
  }
  
  private Key getEncryptionKey()
    throws Exception
  {
    Key encryptionkey = null;
    try
    {
      encryptionkey = new SecretKeySpec(M_SECRETKEYVALUE, "AES");
    }
    catch (Exception e)
    {
      throw new Exception(e.getMessage(), e);
    }
    return encryptionkey;
  }
}
