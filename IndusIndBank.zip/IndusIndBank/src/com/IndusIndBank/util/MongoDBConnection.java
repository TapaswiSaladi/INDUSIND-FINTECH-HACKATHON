package com.IndusIndBank.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

public class MongoDBConnection 
{
	public MongoClient getMongoConnection(Properties prop)
	{
		MongoClient mongoClient = null;
		try 
		{			
			String mongoConnectionURI = prop.getProperty("mongoConnectionURI").trim();
			String mongoDBIP = prop.getProperty("mongoDBIP").trim();
			String mongoDBPort = prop.getProperty("mongoDBPort").trim();
			String mongoDBUsername = prop.getProperty("mongoDBUsername").trim();
			String mongoDBPassword = new AESEncryptDecryptUtil().decryptData(prop.getProperty("mongoDBPassword").trim());
			String mongoDBName = prop.getProperty("mongoDBName").trim();
			
			String conectionURI = mongoConnectionURI.replace("#username#", mongoDBUsername).replace("#password#", mongoDBPassword)
					.replace("#server#", mongoDBIP).replace("#port#", mongoDBPort).replace("#dbName#", mongoDBName);
					
			System.out.println(conectionURI);
			mongoClient = new MongoClient(new MongoClientURI(conectionURI));	
			System.out.println("MongoDB connection established");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return mongoClient;
	}
	
	public void closeMongoConnection(MongoClient mongoClient)
	{
		try
		{
			mongoClient.close();
			System.out.println("closing MongoDB connection");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
