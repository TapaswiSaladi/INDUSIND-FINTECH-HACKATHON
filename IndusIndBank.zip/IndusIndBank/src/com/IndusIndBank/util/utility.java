package com.IndusIndBank.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.IndusIndBank.controller.loginServlet;
import com.IndusIndBank.dao.CustomerOnboardDao;
import com.IndusIndBank.dao.LoginDao;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

public class utility 
{
	
    public static String getCurrentDate()
	{
		String currentDate = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		currentDate = sdf.format(date) + "#" + date.getTime();
		
		return currentDate;
	}
	
	public static long convertDateToTimestamp(String dateInString)
	{
		long timestamp = 0;
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		
        try 
        {
            Date date = formatter.parse(dateInString);
            System.out.println(date);
            System.out.println(date.getTime());
            timestamp = date.getTime();

        } 
        catch (ParseException e) 
        {
            e.printStackTrace();
        }
        return timestamp;
	}
	
	public static String addOneDayAndReturn(String dateInString)
	{
		System.out.println("inside addOneDayAndReturn");
		String dateAfterAddingOneDay = "";
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try 
        {
            Date date = formatter.parse(dateInString);
            
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            System.out.println("Before : " + cal.getTime());
            cal.add(Calendar.DATE, 1); //minus number would decrement the days
            System.out.println("After : " + cal.getTime());
            
            dateAfterAddingOneDay = formatter.format(cal.getTime());

        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println("dateAfterAddingOneDay : " + dateAfterAddingOneDay);
        System.out.println("inside addOneDayAndReturn end");
        return dateAfterAddingOneDay;
	}

	public static void updateOTP(String aadharID)
	{
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionAadharDB = LoginDao.prop.getProperty("mongoCollectionAadharDB").trim();
			
			MongoCollection<Document> AadharDB = database.getCollection(mongoCollectionAadharDB);	
			
			
			int otp = CustomerOnboardDao.generateRandomInt();
			
			@SuppressWarnings("deprecation")
			long count = AadharDB.count(Filters.eq("aadharID", aadharID));
			
			if(count > 0)
			{
				System.out.println("aadhar id found");
				System.out.println("OTP : " + otp);
				Bson filter = new Document("aadharID", aadharID);
				Bson newValue = new Document("otp", otp);
				Bson updateOperationDocument = new Document("$set", newValue);
				AadharDB.updateOne(filter, updateOperationDocument);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
	}

	public static String maskedAccNumber(String number)
	{
		System.out.println("number : " + number);
		String maskedPart = number.substring(4, (number.length()-7)); 
		StringBuilder masked = new StringBuilder();
		for (int i = 0; i < maskedPart.length(); i++) 
		{
			masked.append("X");
		}
		
		number = number.replace(maskedPart, masked.toString());
		System.out.println("masked number : " + number);
		return number;
	}

	public static void sendOTP(String contactNo, String message)
	{

		  String output = "";
		  URL url = null;
		  HttpsURLConnection conn = null;
		  BufferedReader br = null;
		  String timeTaken = null;
		  
		  try 
		  {
			  System.out.println(message);
			// System.out.println(TranslateToHindi.getHindiMsg(message));
			  String restAPI_sendOTP = LoginDao.prop.getProperty("restAPI_sendOTP").trim();
			  restAPI_sendOTP = restAPI_sendOTP.replace("{contactNo}", contactNo);
			  restAPI_sendOTP = restAPI_sendOTP.replace("{message}", message);
			  System.out.println(restAPI_sendOTP);
			  url = new URL(restAPI_sendOTP);
			  conn = (HttpsURLConnection) url.openConnection();
			  conn.setRequestMethod("GET");
			  
			  Long startTime = Long.valueOf(System.currentTimeMillis());

			  if (conn.getResponseCode() != 200) 
			  {
				  throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			  }

			  Long endTime = Long.valueOf(System.currentTimeMillis());
			  Long ExecTime = Long.valueOf(endTime.longValue() - startTime.longValue());
		      long timeMiliSeconds = TimeUnit.MILLISECONDS.toMillis(ExecTime.longValue());
		      timeTaken = Long.toString(timeMiliSeconds);
			  
			  br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			  String line;
			  while ((line = br.readLine()) != null) 
			  {
				  output = output + line + "\n";
			  }
			  br.close();
		  }
		  catch (MalformedURLException e) 
		  {
			  e.printStackTrace();
		  } 
		  catch (IOException e) 
		  {
			  e.printStackTrace();
		  }	
		  finally
		  {
			  if(conn != null)
			  {
				  conn.disconnect();
			  }			
		  }
		 System.out.println("output : " + output);
		 System.out.println("timeTaken : " + timeTaken);
	  
	}
	
	
	
	public static int sendNotificationSMS(String news)
	{
		int smsCount = 0;
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionNewUserDB = LoginDao.prop.getProperty("mongoCollectionNewUserDB").trim();
			
			MongoCollection<Document> NEWUSERDB = database.getCollection(mongoCollectionNewUserDB);	
			
			FindIterable<Document> NEWUSERDBDoc = NEWUSERDB.find(Filters.eq("status", "Active"));
			
			for(Document doc : NEWUSERDBDoc)
			{
				String contactNo = doc.getString("contactNo");
				sendOTP(contactNo,news);
				smsCount++;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		System.out.println("smsCount : " + smsCount);
		return smsCount;
	}
	
	public static int generateRandomInt()
	{
		int max = 999999;
		int min = 100000;
	    Random random = new Random();
	    int otp = random.nextInt((max - min) + 1) + min;
	    System.out.println("OTP : " + otp);
	    return otp;
	}
	
	public static int generateRandomIntAndSendToCustomer()
	{
	    int otp = generateRandomInt();
	    System.out.println("OTP : " + otp);
	    String contactNo = loginServlet.session.getAttribute("contactNo").toString();
	    String message = LoginDao.prop.getProperty("otpMsgPrefix").trim() + " " + otp;
	    sendOTP(contactNo,message);
	    return otp;
	}
	
	public static ArrayList<String> getNewsLetters()
	{
		ArrayList<String> newsList = new ArrayList<String>();
		MongoClient mongoClient = null;
		MongoDBConnection mongoDBConnection = new MongoDBConnection();
		
		try
		{
			mongoClient = mongoDBConnection.getMongoConnection(LoginDao.prop);
			MongoDatabase database = mongoClient.getDatabase(LoginDao.prop.getProperty("mongoDBName").trim());
			String mongoCollectionNewsLettersDB = LoginDao.prop.getProperty("mongoCollectionNewsLettersDB").trim();
			
			MongoCollection<Document> NEWSLETTERSDB = database.getCollection(mongoCollectionNewsLettersDB);	
			FindIterable<Document> NEWSLETTERSDBDoc = NEWSLETTERSDB.find(Filters.eq("status", "Active"));
			
			for(Document doc : NEWSLETTERSDBDoc)
			{
				newsList.add(doc.getString("news"));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			mongoDBConnection.closeMongoConnection(mongoClient);
		}
		return newsList;
	}
}
