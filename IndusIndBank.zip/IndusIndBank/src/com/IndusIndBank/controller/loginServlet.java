package com.IndusIndBank.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.IndusIndBank.dao.LoginDao;
import com.IndusIndBank.util.utility;

/**
 * Servlet implementation class loginServlet
 */
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static HttpSession session = null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String username =  request.getParameter("username");
		String password =  request.getParameter("password");
		
		System.out.println(username + " # " + password);
		
		LoginDao loginDao = new LoginDao();
		boolean loginSuccess = loginDao.validateLogin(username, password);
		
		response.setContentType("text/html");  
		RequestDispatcher requestDispatcher; 
		
		if(loginSuccess)
		{
			session = request.getSession(false);
			session.setAttribute("userID", username);
			session.setAttribute("kiranaID", username);
			requestDispatcher = request.getRequestDispatcher("jsp/kiranaMemberHome.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
