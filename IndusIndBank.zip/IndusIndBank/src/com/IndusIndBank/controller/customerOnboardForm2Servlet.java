package com.IndusIndBank.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.IndusIndBank.bean.UserBean;
import com.IndusIndBank.dao.CustomerOnboardDao;

/**
 * Servlet implementation class loginServlet
 */
public class customerOnboardForm2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public customerOnboardForm2Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher requestDispatcher; 
		
		if(loginServlet.session != null)
		{
			String aadharNo =  request.getParameter("aadharNo");
			String customerName =  request.getParameter("customerName");
			int age =  Integer.parseInt(request.getParameter("age"));
			String contactNo =  request.getParameter("contactNo");
		//	String memberID =  request.getParameter("memberID");
			String otp =  request.getParameter("otp");
			
			UserBean userBean = new UserBean();
			
			userBean.setAadharNo(aadharNo);
			userBean.setCustomerName(customerName);
			userBean.setAge(age);
			userBean.setContactNo(contactNo);
		//	userBean.setKiranaMemberID(memberID);
			userBean.setStatus("Active");
			
			System.out.println(aadharNo + " # " + contactNo);
			
			CustomerOnboardDao customerOnboardDao = new CustomerOnboardDao();
			boolean userAdded = customerOnboardDao.addUser(userBean, otp);
			
			response.setContentType("text/html");  
			
			
			System.out.println("inside customerOnboardForm2Servlet, userAdded status : " + userAdded);
			
			if(userAdded)
			{
				request.setAttribute("userAdded", "true");
			}
			else
			{
				request.setAttribute("userAdded", "false");
			}
			requestDispatcher = request.getRequestDispatcher("jsp/kiranaMemberHome.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
