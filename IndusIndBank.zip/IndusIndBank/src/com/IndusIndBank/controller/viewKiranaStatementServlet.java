package com.IndusIndBank.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.IndusIndBank.bean.CustomerTransactionBean;
import com.IndusIndBank.bean.KiranMemberBean;
import com.IndusIndBank.dao.CustomerAccountDao;
import com.IndusIndBank.util.utility;

/**
 * Servlet implementation class loginServlet
 */
public class viewKiranaStatementServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewKiranaStatementServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{		
		response.setContentType("text/html");  
		RequestDispatcher requestDispatcher; 
		
		if(loginServlet.session != null)
		{
			long startDateTimestamp =  utility.convertDateToTimestamp(request.getParameter("startDate"));
			long endDateTimestamp =  utility.convertDateToTimestamp(utility.addOneDayAndReturn(request.getParameter("endDate")));
			
			CustomerAccountDao customerAccountDao = new CustomerAccountDao();
			
			ArrayList<KiranMemberBean> kiranMemberBeanList = customerAccountDao.getKiranaMemberTransactionDetails(
																				loginServlet.session.getAttribute("kiranaID").toString(),
																				startDateTimestamp, endDateTimestamp);
			double totalMoneyTaken = 0.0;
			double totalMoneyGiven = 0.0;
			
			for(int i=0 ; i<kiranMemberBeanList.size() ; i++)
			{
				totalMoneyTaken += kiranMemberBeanList.get(i).getTotalMoneyTaken();
				totalMoneyGiven += kiranMemberBeanList.get(i).getTotalMoneyGiven();
				
			}
			request.setAttribute("kiranMemberBeanList", kiranMemberBeanList);
			request.setAttribute("totalMoneyTaken", totalMoneyTaken);
			request.setAttribute("totalMoneyGiven", totalMoneyGiven);
			System.out.println("inside servlet");
			System.out.println("totalMoneyTaken : " + totalMoneyTaken);
			System.out.println("totalMoneyGiven : " + totalMoneyGiven);
			
			requestDispatcher = request.getRequestDispatcher("jsp/showKiranaMemberAccountStatement.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
