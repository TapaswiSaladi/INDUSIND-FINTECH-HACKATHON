package com.IndusIndBank.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.IndusIndBank.dao.LoginDao;
import com.IndusIndBank.util.textToSpeech;
import com.IndusIndBank.util.utility;

/**
 * Servlet implementation class loginServlet
 */
public class textToSpeechServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public textToSpeechServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String textToSpeak =  request.getParameter("textToSpeak");
		
		System.out.println("textToSpeak : " + textToSpeak);
		
		textToSpeech.speakOut(textToSpeak);
		
		String referer = request.getHeader("Referer");
		System.out.println("referer : " + referer);
		response.sendRedirect(referer);
		
		/*response.setContentType("text/html");  
		RequestDispatcher requestDispatcher; 
		requestDispatcher = request.getRequestDispatcher("jsp/showCustomerAccountBalance.jsp");
		requestDispatcher.forward(request, response);*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
