package com.IndusIndBank.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.IndusIndBank.dao.LoginDao;
import com.IndusIndBank.util.utility;

/**
 * Servlet implementation class loginServlet
 */
public class sendNotificationSMSServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sendNotificationSMSServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");  
		RequestDispatcher requestDispatcher;
		
		String news =  request.getParameter("news");
		System.out.println("news :  " + news);
		
		int smsCount = utility.sendNotificationSMS(news);
		
		if(smsCount == 0)
		{
			request.setAttribute("smsStats", "No SMS has been sent");
		}
		else
		{
			request.setAttribute("smsStats", "SMS has been sent to " + smsCount + " people");
			System.out.println("SMS has been sent to " + smsCount + " people");
		}
		requestDispatcher = request.getRequestDispatcher("jsp/newsLetters.jsp");
		requestDispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
