package com.IndusIndBank.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.IndusIndBank.bean.UserBean;
import com.IndusIndBank.dao.CustomerDetailsDao;
import com.IndusIndBank.dao.CustomerOnboardDao;

/**
 * Servlet implementation class loginServlet
 */
public class viewAllCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewAllCustomerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher requestDispatcher;
		
		if(loginServlet.session != null)
		{
			System.out.println(loginServlet.session.getAttribute("userID"));
			String userID = loginServlet.session.getAttribute("userID").toString();
			CustomerDetailsDao customerDetailsDao = new CustomerDetailsDao();
			ArrayList<UserBean> userBeanList = customerDetailsDao.viewAllCustomers(userID);
			
			response.setContentType("text/html");   
			
			request.setAttribute("userBeanList", userBeanList);
			requestDispatcher = request.getRequestDispatcher("jsp/displayAllCustomers.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
