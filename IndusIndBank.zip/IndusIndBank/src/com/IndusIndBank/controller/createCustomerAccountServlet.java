package com.IndusIndBank.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.IndusIndBank.bean.AddressBean;
import com.IndusIndBank.bean.CustomerAccountBean;
import com.IndusIndBank.dao.CustomerAccountDao;
import com.IndusIndBank.dao.LoginDao;

/**
 * Servlet implementation class loginServlet
 */
public class createCustomerAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public createCustomerAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		RequestDispatcher requestDispatcher; 		
		
		if(loginServlet.session != null)
		{
			CustomerAccountBean CustomerAccountBean = new CustomerAccountBean();
			
			String accountType = request.getParameter("accountType");
			if(accountType.equalsIgnoreCase("savings"))
			{
				CustomerAccountBean.setCustomerAccNumber(Long.parseLong(loginServlet.session.getAttribute("customerID").toString()
														+ LoginDao.prop.getProperty("savingsAccType")));
			}
			if(accountType.equalsIgnoreCase("current"))
			{
				CustomerAccountBean.setCustomerAccNumber(Long.parseLong(loginServlet.session.getAttribute("customerID").toString()
														+ LoginDao.prop.getProperty("currentAccType")));
			}
			
			CustomerAccountBean.setCustomerID(loginServlet.session.getAttribute("customerID").toString());
			CustomerAccountBean.setAadharNo(loginServlet.session.getAttribute("aadharNo").toString());
			CustomerAccountBean.setAge(Integer.parseInt(loginServlet.session.getAttribute("age").toString()));
			CustomerAccountBean.setCustomerName(request.getParameter("salutation") + " " + request.getParameter("firstName") + " " + request.getParameter("lastName"));
			CustomerAccountBean.setContactNo(request.getParameter("contactNo"));
			CustomerAccountBean.setEmailID((request.getParameter("emailID") !=  null) ? (request.getParameter("emailID")):"");
			CustomerAccountBean.setDob(request.getParameter("dob")); 
			CustomerAccountBean.setNationality(request.getParameter("nationality"));
			CustomerAccountBean.setGender(request.getParameter("gender"));
			CustomerAccountBean.setMaritalStatus(request.getParameter("maritalStatus"));
			CustomerAccountBean.setMotherMaidenName(request.getParameter("motherMaidenName"));
			CustomerAccountBean.setFatherName(request.getParameter("fatherName"));
			CustomerAccountBean.setPanNo(request.getParameter("panNo"));
			CustomerAccountBean.setAddressProof(request.getParameter("addressProof"));
			
			AddressBean addressBean = new AddressBean();
			addressBean.setAddressType(request.getParameter("addressType"));
			addressBean.setAddress(request.getParameter("address") + " ; Near " +
									request.getParameter("landMark") + " ; " +
									request.getParameter("city") + " ; " +
									request.getParameter("state") + " - " +
									request.getParameter("pincode"));
			System.out.println(addressBean.getAddress());
			
			ArrayList<AddressBean> addressList  = new ArrayList<AddressBean>();
			addressList.add(addressBean);
			
			CustomerAccountBean.setAddressList(addressList);
			
			CustomerAccountBean.setAccountType(request.getParameter("accountType"));
			CustomerAccountBean.setOpeningAmount(Double.parseDouble(request.getParameter("openingAmount")));
			CustomerAccountBean.setJointAccHolderName(request.getParameter("jointAccHolderName"));
			
			CustomerAccountDao customerAccountDao = new CustomerAccountDao();
			String output[] = customerAccountDao.createCustomerAccount(CustomerAccountBean).split("\\#");
			String stats = output[0];
			
			if(stats.equalsIgnoreCase("true"))
			{
				long newAccNumber = Long.parseLong(output[1]);
				System.out.println("from createCustomerAccountServlet , newAccNumber: " + newAccNumber);
				CustomerAccountBean.setCustomerAccNumber(newAccNumber);
				customerAccountDao.updateTransactionTableFirstTime(CustomerAccountBean);
				request.setAttribute("customerAccountCreated", "true");
			}
			else
			{
				request.setAttribute("customerAccountCreated", "false");
			}
			requestDispatcher = request.getRequestDispatcher("jsp/customerServiceMenu1.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
