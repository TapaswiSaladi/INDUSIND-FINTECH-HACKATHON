package com.IndusIndBank.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.IndusIndBank.bean.CustomerTransactionBean;
import com.IndusIndBank.dao.CustomerAccountDao;
import com.IndusIndBank.dao.LoginDao;
import com.IndusIndBank.util.utility;

/**
 * Servlet implementation class loginServlet
 */
public class customerDepositWithdrawalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public customerDepositWithdrawalServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{		
		response.setContentType("text/html");  
		RequestDispatcher requestDispatcher; 
		
		if(loginServlet.session != null)
		{
			String customerID = loginServlet.session.getAttribute("customerID").toString();
			CustomerAccountDao customerAccountDao = new CustomerAccountDao();
			
			ArrayList<CustomerTransactionBean> customerAccounts = customerAccountDao.viewAccountBalance(customerID);
			
			String aadharID = customerID.substring(0, 12);
			/*utility.updateOTP(aadharID);*/
			
			request.setAttribute("customerAccounts", customerAccounts);
			System.out.println("customerAccounts.size() = " + customerAccounts.size());
			
			requestDispatcher = request.getRequestDispatcher("jsp/depositWithdrawal.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
