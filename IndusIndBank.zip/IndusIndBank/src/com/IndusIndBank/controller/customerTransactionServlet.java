package com.IndusIndBank.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.IndusIndBank.bean.CustomerTransactionBean;
import com.IndusIndBank.dao.CustomerAccountDao;
import com.IndusIndBank.dao.LoginDao;
import com.IndusIndBank.util.utility;

/**
 * Servlet implementation class loginServlet
 */
public class customerTransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public customerTransactionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{		
		System.out.println("inside customerTransactionServlet");
		response.setContentType("text/html");  
		RequestDispatcher requestDispatcher; 
		System.out.println(loginServlet.session.getAttribute("accountNumber").toString().trim());
		if(loginServlet.session != null)
		{
			CustomerTransactionBean customerTransactionBean = new CustomerTransactionBean();
			
			/*customerTransactionBean.setCustomerAccNumber(Long.parseLong(request.getParameter("accountNumber").toString().trim().split("\\#")[0]));*/
			customerTransactionBean.setCustomerAccNumber(Long.parseLong(loginServlet.session.getAttribute("accountNumber").toString().trim().split("\\#")[0]));
			String [] transactionTimeStampArr = utility.getCurrentDate().split("\\#");
			customerTransactionBean.setTransactionDate(transactionTimeStampArr[0]);
			customerTransactionBean.setCustomerID(loginServlet.session.getAttribute("customerID").toString().trim());
			customerTransactionBean.setCustomerName(loginServlet.session.getAttribute("customerName").toString().trim());
			customerTransactionBean.setContactNo(loginServlet.session.getAttribute("contactNo").toString().trim());
			customerTransactionBean.setEmailID("");
			
			/*double transactionAmount = Double.parseDouble(request.getParameter("transactionAmount").toString().trim());
			String transactionType = request.getParameter("transactionType").toString().trim();*/
			
			double transactionAmount = Double.parseDouble(loginServlet.session.getAttribute("transactionAmount").toString().trim());
			String transactionType = loginServlet.session.getAttribute("transactionType").toString().trim();
			
			if(transactionType.equalsIgnoreCase("Credit"))
			{
				customerTransactionBean.setCreditedAmount(transactionAmount);
				customerTransactionBean.setDebitedAmount(0.0);
			}
			else
			{
				customerTransactionBean.setCreditedAmount(0.0);
				customerTransactionBean.setDebitedAmount(transactionAmount);
			}
			
			customerTransactionBean.setAccountBalance(0.0);
			/*customerTransactionBean.setDescription(request.getParameter("description").toString().trim());*/
			customerTransactionBean.setDescription(loginServlet.session.getAttribute("description").toString().trim());
			customerTransactionBean.setTransactionTimestamp(Long.parseLong(transactionTimeStampArr[1]));
			
			CustomerAccountDao customerAccountDao = new CustomerAccountDao();
			
			String output = customerAccountDao.updateCustomerTransaction(customerTransactionBean);
			
			if(output.toLowerCase().contains("true"))
			{
				System.out.println("Transaction updated");
				request.setAttribute("transactionStatus", "true");
			}
			else
			{
				System.out.println("Transaction failed");
				request.setAttribute("transactionStatus", "false");
			}
			
			requestDispatcher = request.getRequestDispatcher("jsp/customerServiceMenu1.jsp");
			requestDispatcher.forward(request, response);
		}
		else
		{
			requestDispatcher = request.getRequestDispatcher("jsp/logout.jsp");
			requestDispatcher.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
