package com.IndusIndBank.bean;

public class CustomerTransactionBean 
{
	private long customerAccNumber;
	private String transactionDate;
	private String customerID;
	private String customerName;
	private String contactNo;
	private String emailID;
	private double creditedAmount;
	private double debitedAmount;
	private double accountBalance;
	private String description;
	private long transactionTimestamp;
	
	public long getCustomerAccNumber() {
		return customerAccNumber;
	}
	public void setCustomerAccNumber(long customerAccNumber) {
		this.customerAccNumber = customerAccNumber;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public double getCreditedAmount() {
		return creditedAmount;
	}
	public void setCreditedAmount(double creditedAmount) {
		this.creditedAmount = creditedAmount;
	}
	public double getDebitedAmount() {
		return debitedAmount;
	}
	public void setDebitedAmount(double debitedAmount) {
		this.debitedAmount = debitedAmount;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public long getTransactionTimestamp() {
		return transactionTimestamp;
	}
	public void setTransactionTimestamp(long transactionTimestamp) {
		this.transactionTimestamp = transactionTimestamp;
	}
}
