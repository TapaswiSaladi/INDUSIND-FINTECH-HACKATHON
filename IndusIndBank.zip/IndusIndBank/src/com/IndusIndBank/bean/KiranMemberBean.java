package com.IndusIndBank.bean;

public class KiranMemberBean 
{
	private String kiranaMemberID;
	private String customerID;
	private double totalMoneyTaken;
	private double totalMoneyGiven;
	public String getKiranaMemberID() {
		return kiranaMemberID;
	}
	public void setKiranaMemberID(String kiranaMemberID) {
		this.kiranaMemberID = kiranaMemberID;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public double getTotalMoneyTaken() {
		return totalMoneyTaken;
	}
	public void setTotalMoneyTaken(double totalMoneyTaken) {
		this.totalMoneyTaken = totalMoneyTaken;
	}
	public double getTotalMoneyGiven() {
		return totalMoneyGiven;
	}
	public void setTotalMoneyGiven(double totalMoneyGiven) {
		this.totalMoneyGiven = totalMoneyGiven;
	}
}
