package com.IndusIndBank.bean;

public class AlreadyExistCheck 
{
	private String aadharExists;
	private String userExists;
	public String getAadharExists() {
		return aadharExists;
	}
	public void setAadharExists(String aadharExists) {
		this.aadharExists = aadharExists;
	}
	public String getUserExists() {
		return userExists;
	}
	public void setUserExists(String userExists) {
		this.userExists = userExists;
	}
}
