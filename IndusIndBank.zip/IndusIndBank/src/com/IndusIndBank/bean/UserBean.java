package com.IndusIndBank.bean;

public class UserBean 
{
	private String kiranaMemberID;
	private String customerID;
	private String aadharNo;
	private String customerName;
	private int age;
	private String contactNo;	
	private String status;	
	
	public String getKiranaMemberID() {
		return kiranaMemberID;
	}
	public void setKiranaMemberID(String kiranaMemberID) {
		this.kiranaMemberID = kiranaMemberID;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
