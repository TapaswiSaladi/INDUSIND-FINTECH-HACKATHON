package com.IndusIndBank.bean;

import java.util.ArrayList;

public class CustomerAccountBean 
{
	private long customerAccNumber;
	private String accountOpeningDate;
	private String customerID;
	private String aadharNo;
	private int age;
	private String customerName;
	private String contactNo;
	private String emailID;
	private String dob; 
	private String nationality;
	private String gender;
	private String maritalStatus;
	private String motherMaidenName;
	private String fatherName;
	private String panNo;
	private String addressProof;
	private ArrayList<AddressBean> addressList;
	private String accountType;
	private double openingAmount;
	private String jointAccHolderName;
	
	public long getCustomerAccNumber() {
		return customerAccNumber;
	}
	public void setCustomerAccNumber(long customerAccNumber) {
		this.customerAccNumber = customerAccNumber;
	}
	public String getAccountOpeningDate() {
		return accountOpeningDate;
	}
	public void setAccountOpeningDate(String accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}
	public String getCustomerID() {
		return customerID;
	}
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getMotherMaidenName() {
		return motherMaidenName;
	}
	public void setMotherMaidenName(String motherMaidenName) {
		this.motherMaidenName = motherMaidenName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAddressProof() {
		return addressProof;
	}
	public void setAddressProof(String addressProof) {
		this.addressProof = addressProof;
	}
	public ArrayList<AddressBean> getAddressList() {
		return addressList;
	}
	public void setAddressList(ArrayList<AddressBean> addressList) {
		this.addressList = addressList;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getOpeningAmount() {
		return openingAmount;
	}
	public void setOpeningAmount(double openingAmount) {
		this.openingAmount = openingAmount;
	}
	public String getJointAccHolderName() {
		return jointAccHolderName;
	}
	public void setJointAccHolderName(String jointAccHolderName) {
		this.jointAccHolderName = jointAccHolderName;
	}
}
